/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num;
    float cost,disc,finalcost;
    printf("Enter the number of books\n");
    scanf("%d",&num);
    if(num<=10000)
    {
        printf("No discounts!!\n");
        finalcost=num*10;
        printf("finalcost=%f\n",finalcost);
    }
    else if(num>10000 && num<=15000)
    {
        printf("You've got a discount of 10 percent\n");
        cost=num*10;
        disc=(cost*10)/100;
        finalcost=cost-disc;
        printf("finalcost=%f\n",finalcost);
    }
    else if(num>15000 && num<=20000)
    {
    printf("You've got a discount of 20 percent\n");
    cost=num*10;
    disc=(cost*20)/100;
    finalcost=cost-disc;
    printf("finalcost=%f\n",finalcost);
    }

    return 0;
}
