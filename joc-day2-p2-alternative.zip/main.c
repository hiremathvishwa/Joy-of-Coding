/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n1,n2,n3;
    printf("Enter three integers\n");
    scanf("%d %d %d",&n1,&n2,&n3);
    if(n1<0||n2<0||n3<0)
    printf("Invalid input\n");
    else
    {
    if(n1>n2)
    {
        if(n1>n3)
    printf("%d is the largest number\n",n1);
    else printf("%d is the largest number\n",n3);
    }
    else
    {
    if(n2>n3)
    printf("%d is the largest number\n",n2);
    else
    printf("%d is the largest number\n",n3);
    }
    }
}
