/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int rank;
    printf("Enter the rank\n");
    scanf("%d",&rank);
    if(rank<3250)
    printf("Mr.Engineer can get a seat for all branches in RNSIT\n");
   else if(rank>3250 && rank<6505)
    printf("Mr.Engineer can get a seat for all brances except CSE in RNSIT\n");
    else if(rank>6505 && rank<12012)
    printf("Mr.Engineer can get a seat for EandC and MEC\n");
    else if(rank>12012 && rank<25000)
    printf("Mr.Engineer can get a seat for MEC in RNSIT\n");
    else if(rank>25000)
    printf("Mr.Engineer cannot get a seat for any branch in RNSIT\n");
    return 0;
}
