/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float a,b,c;
    char op;
    printf("enter an expression(a+b)\n");
    scanf("%f %c %f",&a,&op,&b);
    switch(op)
    {
        case'+':
        c=a+b;
        printf("sum=%f",c);
        break;
        case'-':
        c=a-b;
        printf("difference=%f",c);
        break;
        case'*':
        c=a*b;
        printf("product=%f",c);
        break;
        case'/':
        if(b==0)
        {
            printf("b cannot be 0");
             }
             c=a/b;
             printf("quotient=%f",c);
             break;
             default:
             printf("invalid operator");
    }
}
