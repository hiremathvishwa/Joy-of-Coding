/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int age,max;
    char eligible,ineligible;
    printf("Enter the age of the person\n");
    scanf("%d",&age);
    max=(age>17)?eligible:ineligible;
    printf("The person is=%d\n",max);
    

    return 0;
}
